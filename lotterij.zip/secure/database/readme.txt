de database naam is Lottery
met daar in de collections (eerste letters zijn hoofdletters)
Lot
Lotterij
User
Winner